<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{"shortname":"blog-hydrock-ru","enablePages":1,"enablePosts":1,"enableDefaultHomePage":1,"position":0}