<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{"key1":"c7ac855449c5d3cc216472593763c7e252c9ec2a","minutesBlocked":5,"numberFailuresAllowed":10,"blackList":[]}